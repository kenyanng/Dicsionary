package sample;
import java.util.ArrayList;
import java.util.List;

public class Dictionary {
    public static List<Word> dic = new ArrayList<>();
}
